<?php
include '../auth/koneksi.php';

$nama               =$_POST['nama'];
$jenis_kelamin      =$_POST['jenis_kelamin'];
$umur               =$_POST['umur'];
$hari_kematian      =$_POST['hari_kematian'];
$tgl_kematian   =$_POST['tgl_kematian'];
$penyebab           =$_POST['penyebab'];
$alamat             =$_POST['alamat'];

$query = mysqli_query($mysqli,"INSERT INTO tb_kematian (nama, jenis_kelamin, umur, hari_kematian, tgl_kematian, penyebab, alamat)
VALUES('$nama','$jenis_kelamin','$umur','$hari_kematian','$tgl_kematian', '$penyebab', '$alamat' )"); 

if ($query) {
    header('location:data-kematian.php');
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}

?>