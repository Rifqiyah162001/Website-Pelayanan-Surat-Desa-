<?php
include '../auth/koneksi.php';

$query = mysqli_query($mysqli,"SELECT * from tb_usaha");

?>
 <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>DATA USAHA</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class=" bg-dark" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-dark text-light"><strong>SI PELAYANAN SURAT</strong></div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="home.php">Dashboard</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kelahiran.php">Surat Kelahiran</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kematian.php">Surat Kematian</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="sktm.php">Surat Tidak Mampu</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="usaha.php">Surat Usaha</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="../index.php">Logout</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                    <button class="btn mt-1 mb-1 " id="sidebarToggle"><i class="fa fa-bars fa-lg"></i></button>
                
                    </div>
                </nav>
                <div class="container-fluid">
                <h2 class="mt-4">DATA SURAT KETERANGAN USAHA</h2>
                <a href="form-tambah-usaha.php" class="btn btn-sm btn-primary mt-3"><i class="fa fa-add"></i>Tambah Data</a>
                    <table table class="table table-bordered table-responsive mt-3" width="100%">
                        <thead class="bg-secondary text-light">
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama Pemilik</th>
                            <th>Jenis Kelamin</th>
                            <th>Nama Usaha</th>
                            <th>Mulai Usaha</th>
                            <th>Alamat Usaha</th>
                            
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no=0;
                            while ($result = mysqli_fetch_array($query)){
                                $no++;
                                ?>
                            <tr>
                                <td><?php echo $no;?></td>
                                <td><?php echo $result['NIK'];?></td>
                                <td><?php echo $result['nama_pemilik'];?></td>
                                <td><?php echo $result['jk_pemilik'];?></td>
                                <td><?php echo $result['nama_usaha'];?></td>
                                <td><?php echo $result['mulai_usaha'];?></td>
                                <td><?php echo $result['alamat_usaha'];?></td>
      
                                <td>
                                    <a href="form-edit-usaha.php?id_usaha=<?php echo $result['id_usaha'];?>" class="btn btn-sm btn-info"><i class="fa fa-edit"></i> Edit</a>
                                    <a href="hapus-data-usaha.php?id_usaha=<?php echo $result['id_usaha'];?>" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i> Hapus</a>
                                </td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
                </div>    
                

        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
