<?php
include '../auth/koneksi.php';

$NIK            =$_POST['NIK'];
$nama_pemohon   =$_POST['nama_pemohon'];
$jk_pemohon     =$_POST['jk_pemohon'];
$tempat_lahir   =$_POST['tempat_lahir'];
$tgl_lahir      =$_POST['tgl_lahir'];
$alamat         =$_POST['alamat'];
$keperluan      =$_POST['keperluan'];

$query = mysqli_query($mysqli,"INSERT INTO tb_sktm (NIK, nama_pemohon, jk_pemohon, tempat_lahir, tgl_lahir ,alamat, keperluan)
VALUES('$NIK','$nama_pemohon','$jk_pemohon','$tempat_lahir','$tgl_lahir', '$alamat', '$keperluan' )"); 

if ($query) {
    header('location:sktm.php');
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}

?>