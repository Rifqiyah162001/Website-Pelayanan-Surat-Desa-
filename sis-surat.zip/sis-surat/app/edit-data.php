<?php
include '../auth/koneksi.php';

$id = $_GET['id'];
$NIK            =$_POST['NIK'];
$nama_bayi      =$_POST['nama_bayi'];
$ttl            =$_POST['ttl'];
$berat_badan    =$_POST['berat_badan'];
$jk_bayi        =$_POST['jk_bayi'];
$nama_ayah      =$_POST['nama_ayah'];
$nama_ibu       =$_POST['nama_ibu'];
$alamat         =$_POST['alamat'];

$query = mysqli_query($mysqli,"UPDATE tb_kelahiran SET 
NIK='$NIK',nama_bayi='$nama_bayi',ttl='$ttl',berat_badan='$berat_badan',jk_bayi='$jk_bayi',
nama_ayah='$nama_ayah',nama_ibu='$nama_ibu',alamat='$alamat' WHERE id='$id'");

header('location:data-kelahiran.php');
?>