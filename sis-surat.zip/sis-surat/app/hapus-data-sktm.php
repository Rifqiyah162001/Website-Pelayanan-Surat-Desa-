<?php
include '../auth/koneksi.php';

If(isset($_GET['id_sktm'])){

    $id_sktm = $_GET['id_sktm'];
    
    }else{
    
    $id_sktm = "id tidak diset";
    
    }
$query = mysqli_query($mysqli, "DELETE FROM tb_sktm WHERE id_sktm = '$id_sktm'");

//header("location: sktm.php");

if ($query) {
    header("location: sktm.php");
  } else {
      echo "Data gagal" ,mysqli_error($mysqli);
  }
//header('location:data-kelahiran.php')
?>