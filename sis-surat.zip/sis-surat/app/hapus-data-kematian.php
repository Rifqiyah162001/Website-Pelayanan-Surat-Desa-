<?php
include '../auth/koneksi.php';

$id_kematian = $_GET['id_kematian'];
$query = mysqli_query($mysqli, "DELETE FROM tb_kematian WHERE id_kematian = '$id_kematian'");

header("location: data-kematian.php");

//header('location:data-kelahiran.php')
?>