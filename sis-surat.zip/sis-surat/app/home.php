<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>HOME</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class=" bg-dark" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-dark text-light"><strong>SI PELAYANAN SURAT</strong></div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="home.php">Dashboard</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kelahiran.php">Surat Kelahiran</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kematian.php">Surat Kematian</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="sktm.php">Surat Tidak Mampu</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="usaha.php">Surat Usaha</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="../index.php">Logout</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn mt-1" id="sidebarToggle"><i class="fa fa-bars fa-lg"></i></button>
                        <!--<button class="btn" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"></button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                                <li class="nav-item active"><a class="nav-link" href="#!">Home</a></li>
                                <li class="nav-item"><a class="nav-link" href="#!">Link</a></li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="#!">Action</a>
                                        <a class="dropdown-item" href="#!">Another action</a>
                                        <div class="dropdown-divider"></div>
                                        <a class="dropdown-item" href="#!">Something else here</a>
                                    </div>
                                </li>
                            </ul>
                        </div> -->
                    </div>
                </nav>
                <!-- Page content-->
                <div class="container-fluid">
                    <h2 class="mt-4">DASHBOARD</h2>
                    <div class="mt-4 p-3 bg-light text-black text-center">
                        <h1>SELAMAT DATANG</h1> 
                        <h1>ADMIN</h1> 
                    </div>
                </div>
            </div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
