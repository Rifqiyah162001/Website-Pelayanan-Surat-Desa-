<?php
include '../auth/koneksi.php';

$NIK            =$_POST['NIK'];
$nama_pemilik   =$_POST['nama_pemilik'];
$jk_pemilik     =$_POST['jk_pemilik'];
$nama_usaha   =$_POST['nama_usaha'];
$mulai_usaha      =$_POST['mulai_usaha'];
$alamat_usaha         =$_POST['alamat_usaha'];


$query = mysqli_query($mysqli,"INSERT INTO tb_usaha (NIK, nama_pemilik, jk_pemilik, nama_usaha, mulai_usaha ,alamat_usaha)
VALUES('$NIK','$nama_pemilik','$jk_pemilik','$nama_usaha','$mulai_usaha', '$alamat_usaha')"); 

if ($query) {
    header('location:usaha.php');
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}

?>