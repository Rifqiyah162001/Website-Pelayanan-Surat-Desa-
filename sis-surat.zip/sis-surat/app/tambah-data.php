<?php
include '../auth/koneksi.php';

$NIK            =$_POST['NIK'];
$nama_bayi      =$_POST['nama_bayi'];
$ttl            =$_POST['ttl'];
$berat_badan    =$_POST['berat_badan'];
$jk_bayi        =$_POST['jk_bayi'];
$nama_ayah      =$_POST['nama_ayah'];
$nama_ibu       =$_POST['nama_ibu'];
$alamat         =$_POST['alamat'];

$query = mysqli_query($mysqli,"INSERT INTO tb_kelahiran (NIK, nama_bayi, ttl, berat_badan, jk_bayi ,nama_ayah, nama_ibu,alamat)
VALUES('$NIK','$nama_bayi','$ttl','$berat_badan','$jk_bayi','$nama_ayah', '$nama_ibu', '$alamat' )"); 

if ($query) {
    header('location:data-kelahiran.php');
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}

?>