<?php
    include '../auth/koneksi.php';

    $id_sktm = $_GET['id_sktm'];
    $query = mysqli_query($mysqli, "SELECT * FROM tb_sktm WHERE id_sktm = '$id_sktm'");
    $result = mysqli_fetch_array($query)
?>
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>DATA SKTM</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class=" bg-dark" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-dark text-light"><strong>SI PELAYANAN SURAT</strong></div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="home.php">Dashboard</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kelahiran.php">Surat Kelahiran</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kematian.php">Surat Kematian</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="sktm.php">Surat Tidak Mampu</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="usaha.php">Surat Usaha</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="../index.php">Logout</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn" id="sidebarToggle"><i class="fa fa-bars"></i></button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    </div>
                </nav>
                <div class="container mt-3">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5><i class="fa fa-edit"></i> Edit Data</h5>
                            </div>

                            <div class="card-body p-3">
                                <form action="edit-data-sktm.php?id_sktm=<?php echo $_GET['id_sktm'];?>" method="post">
                                    <div class="mb-3">
                                        <label for="nik" >NIK</label>
                                        <input type="nik" class="form-control" id="nik" name="NIK" value="<?php echo $result['NIK'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="namapemohon" >Nama Pemohon</label>
                                        <input type="namapemohon" class="form-control" id="namapemohon" name="nama_pemohon" value="<?php echo $result['nama_pemohon'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="jk_pemohon" >Jenis Kelamin</label>
                                        <input type="jk_pemohon" class="form-control" id="jk_pemohon" name="jk_pemohon" value="<?php echo $result['jk_pemohon'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="tempat_lahir" >Tempat Lahir</label>
                                        <input type="tempat_lahir" class="form-control" id="tempat_lahir" name="tempat_lahir" value="<?php echo $result['tempat_lahir'];?>" required>
                                    </div>
                                   

                                    <div class="mb-3">
                                        <label for="alamat" >Alamat</label>
                                        <input type="alamat" class="form-control" id="alamat" name="alamat" value="<?php echo $result['alamat'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="keperluan" >Alamat</label>
                                        <input type="keperluan" class="form-control" id="keperluan" name="keperluan" value="<?php echo $result['keperluan'];?>" required>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary">Edit Data</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>