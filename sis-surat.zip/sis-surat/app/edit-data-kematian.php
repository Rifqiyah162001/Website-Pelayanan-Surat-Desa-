<?php
include '../auth/koneksi.php';

//$id_kematian  =$_GET['id_kematian'];
If(isset($_GET['id_kematian'])){

    $id_kematian = $_GET['id_kematian'];
    
    }else{
    
    $id_kematian = "id tidak diset";
    
    }
$nama               =$_POST['nama'];
$jenis_kelamin      =$_POST['jenis_kelamin'];
$umur               =$_POST['umur'];
$hari_kematian      =$_POST['hari_kematian'];
$tgl_kematian       =$_POST['tgl_kematian'];
$penyebab           =$_POST['penyebab'];
$alamat             =$_POST['alamat'];

$query = mysqli_query($mysqli,"UPDATE tb_kematian SET 
nama='$nama',jenis_kelamin='$jenis_kelamin',umur='$umur',hari_kematian='$hari_kematian',
tgl_kematian='$tgl_kematian',penyebab='$penyebab',alamat='$alamat' WHERE id_kematian='$id_kematian'");


if ($query) {
  echo "data sukses";
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}

?>