<?php
include '../auth/koneksi.php';
If(isset($_GET['id_sktm'])){

    $id_sktm = $_GET['id_sktm'];
    
    }else{
    
    $id_sktm = "id tidak diset";
    
    }
//$id_sktm = $_GET['id_sktm'];
$NIK            =$_POST['NIK'];
$nama_pemohon      =$_POST['nama_pemohon'];
$jk_pemohon            =$_POST['jk_pemohon'];

$tempat_lahir    =$_POST['tempat_lahir'];

$alamat      =$_POST['alamat'];
$keperluan       =$_POST['keperluan'];

$query = mysqli_query($mysqli,"UPDATE tb_sktm SET 
NIK='$NIK',nama_pemohon='$nama_pemohon',jk_pemohon='$jk_pemohon',tempat_lahir='$tempat_lahir',
alamat='$alamat',keperluan='$keperluan'WHERE id_sktm='$id_sktm'");



//
if ($query) {
    header('location:sktm.php');
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}
?>