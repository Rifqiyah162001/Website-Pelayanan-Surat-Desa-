<?php
    include '../auth/koneksi.php';

    $id_usaha = $_GET['id_usaha'];
    $query = mysqli_query($mysqli, "SELECT * FROM tb_usaha WHERE id_usaha = '$id_usaha'");
    $result = mysqli_fetch_array($query)
?>
<head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>DATA USAHA</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class=" bg-dark" id="sidebar-wrapper">
                <div class="sidebar-heading border-bottom bg-dark text-light"><strong>SI PELAYANAN SURAT</strong></div>
                <div class="list-group list-group-flush">
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="home.php">Dashboard</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kelahiran.php">Surat Kelahiran</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="data-kematian.php">Surat Kematian</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="sktm.php">Surat Tidak Mampu</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="usaha.php">Surat Usaha</a>
                    <a class="list-group-item list-group-item-action bg-dark text-light p-3" href="../index.php">Logout</a>
                </div>
            </div>
            <!-- Page content wrapper-->
            <div id="page-content-wrapper">
                <!-- Top navigation-->
                <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                    <div class="container-fluid">
                        <button class="btn" id="sidebarToggle"><i class="fa fa-bars"></i></button>
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    </div>
                </nav>
                <div class="container mt-3">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5><i class="fa fa-edit"></i> Edit Data</h5>
                            </div>

                            <div class="card-body p-3">
                                <form action="edit-data-usaha.php?id_usaha=<?php echo $_GET['id_usaha'];?>" method="post">
                                    <div class="mb-3">
                                        <label for="nik" >NIK</label>
                                        <input type="nik" class="form-control" id="nik" name="NIK" value="<?php echo $result['NIK'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="namapemilik" >Nama Pemilik</label>
                                        <input type="namapemilik" class="form-control" id="namapemilik" name="nama_pemilik" value="<?php echo $result['nama_pemilik'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="jk_pemilik" >Jenis Kelamin</label>
                                        <input type="jk_pemilik" class="form-control" id="jk_pemilik" name="jk_pemilik" value="<?php echo $result['jk_pemilik'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="nama_usaha" >Nama Usaha</label>
                                        <input type="nama_usaha" class="form-control" id="nama_usaha" name="nama_usaha" value="<?php echo $result['nama_usaha'];?>" required>
                                    </div>
                                   

                                    <div class="mb-3">
                                        <label for="mulai_usaha" >Mulai Usaha</label>
                                        <input type="mulai_usaha" class="form-control" id="mulai_usaha" name="mulai_usaha" value="<?php echo $result['mulai_usaha'];?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="alamat_usaha" >Alamat Usaha</label>
                                        <input type="alamat_usaha" class="form-control" id="alamat_usaha" name="alamat_usaha" value="<?php echo $result['alamat_usaha'];?>" required>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary">Edit Data</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>