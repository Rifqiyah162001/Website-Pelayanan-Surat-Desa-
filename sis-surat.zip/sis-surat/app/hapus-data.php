<?php
include '../auth/koneksi.php';

$id = $_GET['id'];
$query = mysqli_query($mysqli, "DELETE FROM tb_kelahiran WHERE id = '$id'");

header("location: data-kelahiran.php");

//header('location:data-kelahiran.php')
?>