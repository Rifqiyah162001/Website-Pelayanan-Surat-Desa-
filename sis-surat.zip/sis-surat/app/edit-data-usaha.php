<?php
include '../auth/koneksi.php';
If(isset($_GET['id_usaha'])){

    $id_usaha = $_GET['id_usaha'];
    
    }else{
    
    $id_usaha = "id tidak diset";
    
    }
//$id_sktm = $_GET['id_sktm'];
$NIK            =$_POST['NIK'];
$nama_pemilik      =$_POST['nama_pemilik'];
$jk_pemilik            =$_POST['jk_pemilik'];

$nama_usaha    =$_POST['nama_usaha'];

$mulai_usaha      =$_POST['mulai_usaha'];
$alamat_usaha       =$_POST['alamat_usaha'];

$query = mysqli_query($mysqli,"UPDATE tb_usaha SET 
NIK='$NIK',nama_pemilik='$nama_pemilik',jk_pemilik='$jk_pemilik',nama_usaha='$nama_usaha',
mulai_usaha='$mulai_usaha',alamat_usaha='$alamat_usaha'WHERE id_usaha='$id_usaha'");



//
if ($query) {
    header('location:usaha.php');
} else {
    echo "Data gagal" ,mysqli_error($mysqli);
}
?>