<?php
include '../auth/koneksi.php';

If(isset($_GET['id_usaha'])){

    $id_usaha = $_GET['id_usaha'];
    
    }else{
    
    $id_usaha = "id tidak diset";
    
    }
$query = mysqli_query($mysqli, "DELETE FROM tb_usaha WHERE id_usaha = '$id_usaha'");

//header("location: sktm.php");

if ($query) {
    header("location: usaha.php");
  } else {
      echo "Data gagal" ,mysqli_error($mysqli);
  }
//header('location:data-kelahiran.php')
?>