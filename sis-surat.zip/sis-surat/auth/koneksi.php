<?php
$host   = 'localhost';
$dbname = 'sis-surat';
$user   = 'root';
$pass   = '';

$mysqli = mysqli_connect($host,$user,$pass,$dbname);

if (!$mysqli) {
    die("Koneksi gagal" . mysqli_connect_error());
}
//echo "Berhasil";
?>